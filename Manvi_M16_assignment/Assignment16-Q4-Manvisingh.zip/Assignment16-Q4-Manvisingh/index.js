console.log("time colmplexity is o(n+m)");
console.log("space colmplexity is o(n)");