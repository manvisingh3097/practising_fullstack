let num = parseInt(window.prompt("enter a number"));


if (num>=0 && num<=100){

for (let i = 1; i <=num; i++) {

    console.log(i);
    
}}
else 
{
    console.log("The number is not in the [0, 100] interval.")
}

