let password = window.prompt("enter your password")
if (password.length>=8) {
    console.log("acceptable")}
else
{
    alert("not acceptable")
}
    

